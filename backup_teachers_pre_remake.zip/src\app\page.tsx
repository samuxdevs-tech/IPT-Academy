'use client';

import React, { useEffect, useState, Suspense } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { ref, get, set } from 'firebase/database';
import { db } from '@/lib/firebase';
import { Course } from '@/types';
import { normalizeCourse, cleanForFirebase } from '@/lib/courseUtils';
import WelcomeStudioView from '@/components/WelcomeStudioView';
import TeacherStudioWorkspaceView from '@/components/TeacherStudioWorkspaceView';
import MinimalistWorkspaceSelector from '@/components/MinimalistWorkspaceSelector';
import CourseSpreadsheetManager from '@/components/CourseSpreadsheetManager';
import CreateCourseModal from '@/components/CreateCourseModal';
import AdvancedAdminToolsModal from '@/components/AdvancedAdminToolsModal';
import LiveClassesStudioModal from '@/components/LiveClassesStudioModal';

function AdminStudioContent() {
  const searchParams = useSearchParams();
  const router = useRouter();

  const currentView = searchParams?.get('view');
  const requestedCourse = searchParams?.get('course') || undefined;
  const legacyStep = searchParams?.get('step');
  const queryWorkspace = searchParams?.get('workspace') as 'teacher' | 'admin' | null;

  const [workspace, setWorkspace] = useState<'teacher' | 'admin' | null>(null);
  const [courses, setCourses] = useState<Course[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isCreateCourseModalOpen, setIsCreateCourseModalOpen] = useState(false);
  const [isAdminToolsModalOpen, setIsAdminToolsModalOpen] = useState(false);
  const [isLiveStudioModalOpen, setIsLiveStudioModalOpen] = useState(false);

  // Sincronizar espacio de trabajo desde query param o almacenamiento local
  useEffect(() => {
    if (queryWorkspace === 'teacher' || queryWorkspace === 'admin') {
      setWorkspace(queryWorkspace);
      return;
    }
    if (currentView === 'courses' || legacyStep) {
      setWorkspace('admin');
      return;
    }
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('ipt_studio_workspace') as 'teacher' | 'admin' | null;
      if (saved === 'teacher' || saved === 'admin') {
        setWorkspace(saved);
      }
    }
  }, [queryWorkspace, currentView, legacyStep]);

  const handleSelectWorkspace = (selected: 'teacher' | 'admin' | null) => {
    setWorkspace(selected);
    if (typeof window !== 'undefined') {
      if (selected) {
        localStorage.setItem('ipt_studio_workspace', selected);
      } else {
        localStorage.removeItem('ipt_studio_workspace');
      }
    }
    const params = new URLSearchParams(searchParams?.toString() || '');
    if (selected) {
      params.set('workspace', selected);
    } else {
      params.delete('workspace');
      params.delete('view');
      params.delete('course');
      params.delete('step');
    }
    router.push(`/?${params.toString()}`);
  };

  // Cargar cursos desde Firebase Realtime Database
  const loadCourses = async () => {
    try {
      const snap = await get(ref(db, 'courses'));
      if (snap.exists()) {
        const data = snap.val();
        const coursesArray = Object.keys(data).map((key) =>
          normalizeCourse({
            ...data[key],
            slug: data[key].slug || key,
          })
        );
        setCourses(coursesArray);
      } else {
        setCourses([]);
      }
    } catch (e) {
      console.warn('Error cargando cursos:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadCourses();
  }, []);

  // Actualizar curso completo en Firebase
  const handleUpdateCourse = async (updated: Course) => {
    const normalized = normalizeCourse(updated);
    const cleanData = cleanForFirebase(normalized);
    await set(ref(db, `courses/${normalized.slug}`), cleanData);
    setCourses((prev) =>
      prev.map((c) => (c.slug === normalized.slug ? normalized : c))
    );
  };

  // Crear nuevo curso en Firebase
  const handleCreateCourse = async (newCourse: Course) => {
    const normalized = normalizeCourse(newCourse);
    const cleanData = cleanForFirebase(normalized);
    await set(ref(db, `courses/${normalized.slug}`), cleanData);
    setCourses((prev) => [...prev, normalized]);
    router.push(`/?workspace=admin&view=courses&course=${normalized.slug}`);
  };

  if (isLoading) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center min-h-[60vh] space-y-3">
        <div className="w-6 h-6 border-2 border-[#0071e3] border-t-transparent rounded-full animate-spin" />
        <span className="text-xs font-semibold text-[#8e8e93]">Sincronizando campus...</span>
      </div>
    );
  }

  const isSpreadsheetView = currentView === 'courses' || !!legacyStep;

  // 1. PANTALLA PRINCIPAL MINIMALISTA: Si no hay espacio seleccionado, mostrar selector
  if (!workspace && !isSpreadsheetView) {
    return (
      <MinimalistWorkspaceSelector onSelectWorkspace={handleSelectWorkspace} />
    );
  }

  // 2. ESPACIO DOCENTE (NIVEL 2 Y 3)
  if (workspace === 'teacher') {
    return (
      <>
        <LiveClassesStudioModal
          isOpen={isLiveStudioModalOpen}
          onClose={() => setIsLiveStudioModalOpen(false)}
        />
        <TeacherStudioWorkspaceView
          onOpenLiveStudio={() => setIsLiveStudioModalOpen(true)}
          onResetWorkspace={() => handleSelectWorkspace(null)}
        />
      </>
    );
  }

  // 3. ESPACIO ADMINISTRADOR (NIVEL SUPERIOR A 3)
  return (
    <>
      <CreateCourseModal
        isOpen={isCreateCourseModalOpen}
        onClose={() => setIsCreateCourseModalOpen(false)}
        onCreateCourse={handleCreateCourse}
      />

      <AdvancedAdminToolsModal
        isOpen={isAdminToolsModalOpen}
        onClose={() => setIsAdminToolsModalOpen(false)}
        courses={courses}
        assignments={[]}
      />

      <LiveClassesStudioModal
        isOpen={isLiveStudioModalOpen}
        onClose={() => setIsLiveStudioModalOpen(false)}
      />

      {isSpreadsheetView ? (
        <CourseSpreadsheetManager
          courses={courses}
          initialCourseSlug={requestedCourse}
          onUpdateCourse={handleUpdateCourse}
          onOpenCreateCourse={() => setIsCreateCourseModalOpen(true)}
        />
      ) : (
        <WelcomeStudioView
          onOpenCreateCourse={() => setIsCreateCourseModalOpen(true)}
          onOpenAdminTools={() => setIsAdminToolsModalOpen(true)}
          onOpenLiveStudio={() => setIsLiveStudioModalOpen(true)}
          onResetWorkspace={() => handleSelectWorkspace(null)}
        />
      )}
    </>
  );
}

export default function AdminStudioWorkspace() {
  return (
    <Suspense
      fallback={
        <div className="flex-1 flex flex-col items-center justify-center min-h-[60vh] space-y-3">
          <div className="w-6 h-6 border-2 border-[#0071e3] border-t-transparent rounded-full animate-spin" />
          <span className="text-xs font-semibold text-[#8e8e93]">Abriendo IPT Course Studio...</span>
        </div>
      }
    >
      <AdminStudioContent />
    </Suspense>
  );
}
